let playbtn=document.getElementById('play-btn');
let video=document.querySelector('.video');
let isvideoplaying= false;
let Progressbar=document.querySelector(".progress-bar");
let progress_Range=document.querySelector(".progress-range");

//Write functions

function pauseorplay() {
  
 if (!isvideoplaying) {
   
 video.play();
  isvideoplaying=true;
  playbtn.classList.replace('fa-play','fa-pause');
  }
  
else{
video.pause();
isvideoplaying=false;
playbtn.classList.replace('fa-pause','fa-play');
}
}
//progressbar//

function updateProgressbar(event){
	let currentTime = event.target.currentTime;
	let duration= event.target.duration;
	
	Progressbar.style.cssText = ` 
	 width: ${(currentTime/duration)* 100}%`;
}

function updateseekbar(event){
	
let currentpoint = event.offsetX;
	let progresbarwidth=event.target.clientWidth;

	let currentrange =(currentpoint / progresbarwidth) * video.duration;


	video.currentTime = currentrange;
}


// Add event Listeners//

playbtn.addEventListener('click',pauseorplay);
video.addEventListener('click',pauseorplay);
video.addEventListener('timeupdate',updateProgressbar);
progress_Range.addEventListener('click',updateseekbar);